#  ###########################
# 不要删除或重命名chorddict.txt
#  ###########################
#  编译：g++ chordTranslater.cpp -O2 -std=c++11 -o chordTranslater.exe
#  ###########################
#  运行：chordTranslater.exe 时间煮雨和弦.txt 时间煮雨和弦.chordTrans
#  ###########################